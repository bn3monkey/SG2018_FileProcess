#include "shell.hpp"
#include <string>
using namespace std;

//RecordFile <Member> mfile;
//RecordFile <Lecture> lfile;
//RecordFile <Purchase> pfile;

int End()
{
	//Nothing
	cout << "--Program End--" << endl;
	return 0;
}
int showMember()
{
	cout << "--Show Member--" << endl;
	return showScheme<Member>("listOfMember.txt");
}
int MemberTest()
{
	cout << "--Member Test--" << endl;
	return SchemeTest<Member>("listOfMember.txt" , "listOfMember.dat");
}

int showLecture()
{
	cout << "--Show Member--" << endl;
	return showScheme<Lecture>("listOfLecture.txt");
}
int LectureTest()
{
	cout << "--Lecture Test--" << endl;
	return SchemeTest<Lecture>("listOfLecture.txt", "listOfLecture.dat");
}

int showPurchase()
{
	cout << "--Purchase Test--" << endl;
	return showScheme<Purchase>("listOfPurchase.txt");
}
int PurchaseTest()
{
	cout << "--Purchase Test--" << endl;
	return SchemeTest<Purchase>("listOfPurchase.txt", "listOfPurchase.dat");
}
int LecturPurchaseSystem()
{
	RecordFile <Member> MemberFile(DelimFieldBuffer('|', STDMAXBUF));
	RecordFile <Lecture> LectureFile(DelimFieldBuffer('|', STDMAXBUF));

	

	while (true)
	{
		int number, t;
		std::string str;
		cout << "1. Member" << endl;
		cout << "2. Lecture" << endl;
		cout << "3. Purchase" << endl;
		cout << "4. Exit!" << endl;
		cin >> number;

		if (number == 1)
		{
			
			cout << "---------------------" << endl;
			cout << "1. Member find" << endl;
			cout << "2. Member insert" << endl;
			cout << "3. Member delete" << endl;
			cout << "4. Member update" << endl;
			cout << "---------------------" << endl;
			cin >> number;

			MemberFile.Open("listOfMember.dat", ios::in | ios::out);
			cout << "---- Member List ----" << endl;
			for (int read_addr = 0; read_addr != -1; )
			{
				Member m;
				read_addr = MemberFile.Read(m);
				if (read_addr != -1)
					cout << m;
			}
			cout << "---------------------" << endl;
			Member m;
			switch (number)
			{
			case 1:
				cout << "insert MemberID" << endl;
				cin >> str;
				m.update_ID(str);
				if (t = MemberFile.Find(m))
				{
					MemberFile.Read(m, t);
					cout << m << "-- Found --" << endl;
				}
				else
					cout << "No exist!" << endl;
				break;
			case 2:
				cout << "insert MemberID" << endl;
				cin >> str;
				m.update_ID(str);
				if (t = MemberFile.Find(m))
				{
					MemberFile.Read(m, t);
					MemberFile.Append(m);

					cout << "---- Member List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Member m;
						read_addr = MemberFile.Read(m);
						if (read_addr != -1)
							cout << m;
					}
				}
				else
					cout <<  "-- Found --" << endl;
				break;
			case 3:
				cout << "insert MemberID" << endl;
				cin >> str;
				m.update_ID(str);
				if (t = MemberFile.Find(m))
				{
					MemberFile.Read(m, t);
					MemberFile.Delete(m);

					cout << "---- Member List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Member m;
						read_addr = MemberFile.Read(m);
						if (read_addr != -1)
							cout << m;
					}
				}
				else
					cout << "No exist!" << endl;
				break;

			case 4:
				cout << "insert MemberID" << endl;
				cin >> str;
				m.update_ID(str);
				if (t = MemberFile.Find(m))
				{
					MemberFile.Read(m, t);
					MemberFile.Delete(m);

					cout << "What do you want to update!\n" << endl;
					cout << "1. Password" << endl;
					cout << "2. Name" << endl;
					cout << "3. PhoneNumber" << endl;
					cout << "4. Address" << endl;

					int species;
					cin >> species;
					cout << "Type it." << endl;
					cin >> str;

					switch (species)
					{
					case 1: m.update_Password(str); break;
					case 2: m.update_Name(str); break;
					case 3: m.update_PhoneNumber(str); break;
					case 4: m.update_Address(str); break;
					}

					MemberFile.Append(m);

					cout << "---- Member List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Member m;
						read_addr = MemberFile.Read(m);
						if (read_addr != -1)
							cout << m;
					}
				}
				else
					cout << "No exist!" << endl;
				break;
			}
			MemberFile.Close();
		}
		else if (number == 2)
		{
			
			cout << "---------------------" << endl;
			cout << "1. Lecture find" << endl;
			cout << "2. Lecture insert" << endl;
			cout << "3. Lecture delete" << endl;
			cout << "---------------------" << endl;
			cin >> number;

			cout << "---- Lecture List ----" << endl;
			for (int read_addr = 0; read_addr != -1; )
			{
				Member m;
				read_addr = MemberFile.Read(m);
				if (read_addr != -1)
					cout << m;
			}
			cout << "---------------------" << endl;
			LectureFile.Open("listOfLecture.dat", ios::in | ios::out);
			Lecture l;
			switch (number)
			{
			case 1:
				cout << "insert LectureID" << endl;
				cin >> str;
				l.update_lectureid(str);
				if (t = LectureFile.Find(l))
				{
					LectureFile.Read(l, t);
					cout << l << "exist!" << endl;
				}
				else
					cout << "No exist!" << endl;
				break;
			case 2:
				cout << "insert LectureID" << endl;
				cin >> str;
				l.update_lectureid(str);
				if (t = LectureFile.Find(l))
				{
					LectureFile.Read(l, t);
					LectureFile.Append(l);

					cout << "---- Lecture List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Lecture m;
						read_addr = LectureFile.Read(m);
						if (read_addr != -1)
							cout << m;
					}
					cout << "---------------------" << endl;
				}
				else
					cout << "No exist!" << endl;
				break;
			case 3:
				cout << "insert LectureID" << endl;
				cin >> str;
				l.update_lectureid(str);
				if (t = LectureFile.Find(l))
				{
					LectureFile.Read(l, t);
					LectureFile.Delete(l);

					cout << "---- Lecture List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Lecture m;
						read_addr = LectureFile.Read(m);
						if (read_addr != -1)
							cout << m;
					}
					cout << "---------------------" << endl;
				}
				else
					cout << "No exist!" << endl;
				break;

			case 4:
				cout << "insert MemberID" << endl;
				cin >> str;
				l.update_lectureid(str);
				if (t = LectureFile.Find(l))
				{
					LectureFile.Read(l, t);
					LectureFile.Delete(l);

					cout << "What do you want to update!\n" << endl;
					cout << "1. Subject" << endl;
					cout << "2. Level" << endl;
					cout << "3. Price" << endl;
					cout << "4. Extension" << endl;
					cout << "5. Due_date" << endl;
					cout << "6. Name_of_teacher" << endl;
					cout << "7. Textbook" << endl;

					int species;
					cin >> species;
					cout << "Type it." << endl;
					cin >> str;

					switch (species)
					{
					case 1: l.update_subject(str); break;
					case 2: l.update_level(str); break;
					case 3: l.update_price(str); break;
					case 4: l.update_extension(str); break;
					case 5: l.update_duedate(str); break;
					case 6: l.update_nameofteacher(str); break;
					case 7: l.update_textbook(str); break;
					}

					LectureFile.Append(l);

					cout << "---- Lecture List ----" << endl;
					for (int read_addr = 0; read_addr != -1; )
					{
						Member m;
						read_addr = LectureFile.Read(l);
						if (read_addr != -1)
							cout << l;
					}
				}
				else
					cout << "No exist!" << endl;
				break;
			}
			LectureFile.Close();
		}
		else if (number == 4)
		{
			break;
		}
	}




	return 0;
}

int (*prog_table[prog_len])() = 
{
	End, 
	showMember,
	showLecture,
	showPurchase,
	MemberTest,
	LectureTest,
	PurchaseTest,
	LecturPurchaseSystem,
};