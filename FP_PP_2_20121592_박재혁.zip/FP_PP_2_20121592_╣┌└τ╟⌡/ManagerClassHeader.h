#pragma once
#include "MemberManager.hpp"
#include "LectureManager.hpp"
#include "PurchaseManager.hpp"

#include "interface.h"