#pragma once
#include "Lecture.hpp"
#include "Member.hpp"
#include "Purchase.hpp"